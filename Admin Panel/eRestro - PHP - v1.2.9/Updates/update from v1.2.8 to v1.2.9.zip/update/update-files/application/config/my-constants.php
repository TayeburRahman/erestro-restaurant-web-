<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Separate File For Custom Constant Variables



define('FORMS','forms/');
define('TABLES','tables/');






?>