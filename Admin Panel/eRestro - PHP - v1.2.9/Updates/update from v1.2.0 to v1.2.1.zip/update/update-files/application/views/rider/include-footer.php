<footer class="main-footer text-right">
	<strong>Copyright &copy; 2021-2022 <a href="<?=base_url('admin/home')?>"><?php $settings=get_settings('system_settings',true); echo $settings['app_name'];?></a>.</strong>
	All rights reserved.
	<div class="float-right d-none d-sm-inline-block">
	</div>
</footer>